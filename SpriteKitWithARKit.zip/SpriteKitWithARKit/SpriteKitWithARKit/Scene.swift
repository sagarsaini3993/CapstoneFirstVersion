//
//  Scene.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-08.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//

import SpriteKit
import ARKit
import GameplayKit

class Scene: SKScene, SKPhysicsContactDelegate{
   
    var enemyArray:[SKNode] = []
    var coins:SKNode!
     var Result:Bool = false
 
    
    override func didMove(to view: SKView) {
        // Setup your scene here
        self.scene?.physicsWorld.contactDelegate = self
        
        let enemy = self.childNode(withName: "enemy")
        let enemy2 = self.childNode(withName: "enemy2")
        let enemy3 = self.childNode(withName: "enemy3")
        self.enemyArray.append(enemy!)
        self.enemyArray.append(enemy2!)
       self.enemyArray.append(enemy3!)
        self.coins = self.childNode(withName: "coins")
      
      
        updatePosition()
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
//        if(self.enemy.position.y <= self.frame.size.height - 300)
//        {
//            self.enemy.position.y = self.enemy.position.y - 10;
//        }
        
       updatePosition()
    }
    
    //function to notify when two sprites touch
    func didBegin(_ contact: SKPhysicsContact) {
        let nodeA = contact.bodyA.node
         let nodeB = contact.bodyB.node
        
        if(nodeA?.name == "enemy" && nodeB?.name == "coins")
        {
            print("enemy reached to coins")
            let messageLabel = SKLabelNode(text: "You Lose Money")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeB?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "coins" && nodeB?.name == "enemy")
        {
            print("enemy reached to coins")
            let messageLabel = SKLabelNode(text: "You Lose Money")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeA?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "enemy2" && nodeB?.name == "coins")
        {
            print("enemy reached to coins")
            let messageLabel = SKLabelNode(text: "You Lose Money")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeB?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "coins" && nodeB?.name == "enemy2")
        {
            print("enemy reached to coins")
            let messageLabel = SKLabelNode(text: "You Lose Money")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeA?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let sceneView = self.view as? ARSKView else {
            return
        }
        
        // Create anchor using the camera's current position
        if let currentFrame = sceneView.session.currentFrame {
            
            // Create a transform with a translation of 0.2 meters in front of the camera
            var translation = matrix_identity_float4x4
            translation.columns.3.z = -0.2
            let transform = simd_mul(currentFrame.camera.transform, translation)
            
            // Add a new anchor to the session
            let anchor = ARAnchor(transform: transform)
            sceneView.session.add(anchor: anchor)
        }
    }
    func updatePosition()
    {
        for (i,enemy) in self.enemyArray.enumerated()
        {
        var a : CGFloat
        var b : CGFloat
        var distance : CGFloat
        var xn : CGFloat
        var yn : CGFloat
        
        a = CGFloat(coins.position.x - enemy.position.x)
        b = CGFloat(coins.position.y - enemy.position.y)
        distance = sqrt(a * a) + (b * b)
        
        //calculate the rate
        xn = a/distance
        yn = b/distance
        
        //move the enemy toward coin
        enemy.position.x = enemy.position.x + CGFloat(xn * 150)
        enemy.position.y = enemy.position.y + CGFloat(yn * 150)
            
            //physics body
            let enemyBodyTexture = SKTexture(imageNamed: "enemy_128")
            enemy.physicsBody = SKPhysicsBody(texture: enemyBodyTexture,
                                            size: enemyBodyTexture.size())
            enemy.physicsBody?.isDynamic = true
            enemy.physicsBody?.allowsRotation = false
            enemy.physicsBody?.affectedByGravity = false
            enemy.physicsBody?.categoryBitMask = 2
            enemy.physicsBody?.collisionBitMask = 1
            enemy.physicsBody?.contactTestBitMask = 1
            enemy.name = "enemy"
            print("Where is enemy ? \(enemy.position.x), \(enemy.position.y)")
        }
    }
    func MoveToNextLevel()
    {
    if (Result == true)
    {
        let scene = SKScene(fileNamed:"Scene2")
        if (scene == nil) {
            print("Error loading level")
            return
        }
        else {
            scene!.scaleMode = .aspectFill
            view?.presentScene(scene!)
        }
        }
     }
}
