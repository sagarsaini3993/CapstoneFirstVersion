//
//  Scene3.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-09.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//

//
//  Scene2.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-08.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//


import SpriteKit
import ARKit
import GameplayKit

class Scene3: SKScene, SKPhysicsContactDelegate{
    
    var enemy = SKSpriteNode(imageNamed: "enemy_128")
    var enemy2 = SKSpriteNode(imageNamed: "enemy_128")
    var enemy3 = SKSpriteNode(imageNamed: "enemy_128")
    var family = SKSpriteNode(imageNamed: "family_128")
    var bullet = SKSpriteNode(imageNamed: "bullet")
    var bullet2 = SKSpriteNode(imageNamed: "bullet")
    var bullet3 = SKSpriteNode(imageNamed: "bullet")
    var enemyArray:[SKNode] = []
    var bulletArray:[SKNode] = []
    var Result:Bool = false
     var movingRight:Bool = true
    
    
    override func didMove(to view: SKView) {
        // Setup your scene here
        self.scene?.physicsWorld.contactDelegate = self
       
        self.enemyArray.append(enemy)
        self.enemyArray.append(enemy2)
        self.enemyArray.append(enemy3)
        self.bulletArray.append(bullet)
        self.bulletArray.append(bullet2)
        self.bulletArray.append(bullet3)
        
        makeEnemies()
        updatePosition()
    }
    
    override func update(_ currentTime: TimeInterval) {
        updatePosition()
    }
    
    //function to notify when two sprites touch
    func didBegin(_ contact: SKPhysicsContact) {
        let nodeA = contact.bodyA.node
        let nodeB = contact.bodyB.node
        
        if(nodeA?.name == "bullet" && nodeB?.name == "family")
        {
            print("bullet hit family")
            let messageLabel = SKLabelNode(text: "You Lose Family")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeB?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "family" && nodeB?.name == "bullet")
        {
            print("bullet hit family")
            let messageLabel = SKLabelNode(text: "You Lose Family")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeA?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "bullet2" && nodeB?.name == "family")
        {
            print("bullet hit family")
            let messageLabel = SKLabelNode(text: "You Lose Family")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeB?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "family" && nodeB?.name == "bullet2")
        {
            print("bullet hit family")
            let messageLabel = SKLabelNode(text: "You Lose Family")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeA?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "bullet3" && nodeB?.name == "family")
        {
            print("bullet hit family")
            let messageLabel = SKLabelNode(text: "You Lose Family")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeB?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        else if(nodeA?.name == "family" && nodeB?.name == "bullet3")
        {
            print("bullet hit family")
            let messageLabel = SKLabelNode(text: "You Lose Family")
            messageLabel.fontColor = UIColor.yellow
            messageLabel.fontSize = 60
            messageLabel.position.x = self.frame.size.width/2
            messageLabel.position.y = self.frame.size.height/2
            addChild(messageLabel)
            nodeA?.removeFromParent()
            Result = true
            MoveToNextLevel()
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let sceneView = self.view as? ARSKView else {
            return
        }
        
        // Create anchor using the camera's current position
        if let currentFrame = sceneView.session.currentFrame {
            
            // Create a transform with a translation of 0.2 meters in front of the camera
            var translation = matrix_identity_float4x4
            translation.columns.3.z = -0.2
            let transform = simd_mul(currentFrame.camera.transform, translation)
            
            // Add a new anchor to the session
            let anchor = ARAnchor(transform: transform)
            sceneView.session.add(anchor: anchor)
        }
    }
    func updatePosition()
    {
        for (i,bullet) in self.bulletArray.enumerated()
        {
            var a : CGFloat
            var b : CGFloat
            var distance : CGFloat
            var xn : CGFloat
            var yn : CGFloat

            a = CGFloat(family.position.x - bullet.position.x)
            b = CGFloat(family.position.y - bullet.position.y)
            distance = sqrt(a * a) + (b * b)

            //calculate the rate
            xn = a/distance
            yn = b/distance

            //move the bullet toward family
            bullet.position.x = bullet.position.x + CGFloat(xn * 150)
            bullet.position.y = bullet.position.y + CGFloat(yn * 150)
        }
        for (i,enemy) in self.enemyArray.enumerated()
        {
            var a : CGFloat
            var b : CGFloat
            var distance : CGFloat
            var xn : CGFloat
            var yn : CGFloat
            
            a = CGFloat(family.position.x - enemy.position.x)
            b = CGFloat(family.position.y - enemy.position.y)
            distance = sqrt(a * a) + (b * b)
            
            //calculate the rate
            xn = a/distance
            yn = b/distance
            
            //move the enemy toward family
            enemy.position.x = enemy.position.x + CGFloat(xn * 150)
            enemy.position.y = enemy.position.y + CGFloat(yn * 150)
        }
        if(movingRight == true)
        {
            print("family is moving right")
            family.position.x = family.position.x + 5
            if(family.position.x >= self.frame.width - 100)
            {
                movingRight = false
            }
        }
        if(movingRight == false)
        {
            
            print("family is moving left")
            family.position.x = family.position.x - 5
            if(family.position.x <=  100)
            {
                movingRight = true
            }
        }
        
    }
    func MoveToNextLevel()
    {
        if (Result == true)
        {
            let scene = SKScene(fileNamed:"Scene")
            if (scene == nil) {
                print("Error loading level")
                return
            }
            else {
                scene!.scaleMode = .aspectFill
                view?.presentScene(scene!)
            }
        }
    }
    //make enemies
    func makeEnemies()
    {
        //enemies moving toward family
        for (i,enemy) in self.enemyArray.enumerated()
        {
            let randX = Int(CGFloat((UInt32(self.size.width - 500 ))))
            let randY = Int(CGFloat((UInt32(self.size.height - 200))))
            
            enemyArray[i].position = CGPoint(x:randX + (i*80), y:randY - (i*50))
            bulletArray[i].position = enemyArray[i].position
            print("Where is enemy? \(randX), \(randY)")
            
            addChild(enemyArray[i])
            addChild(bulletArray[i])
            //physics for enemy
            let enemyBodyTexture = SKTexture(imageNamed: "enemy_128")
            enemy.physicsBody = SKPhysicsBody(texture: enemyBodyTexture,
                                              size: enemyBodyTexture.size())
            enemy.physicsBody?.isDynamic = true
            enemy.physicsBody?.allowsRotation = false
            enemy.physicsBody?.affectedByGravity = false
            enemy.physicsBody?.categoryBitMask = 2
            enemy.physicsBody?.collisionBitMask = 1
            enemy.physicsBody?.contactTestBitMask = 1
            enemy.name = "enemy"
        
            //physics for bullets
            let bulletBodyTexture = SKTexture(imageNamed: "bullet")
            bullet.physicsBody = SKPhysicsBody(texture: bulletBodyTexture,
                                              size: bulletBodyTexture.size())
            bullet.physicsBody?.isDynamic = true
            bullet.physicsBody?.allowsRotation = false
            bullet.physicsBody?.affectedByGravity = false
            bullet.physicsBody?.categoryBitMask = 4
            bullet.physicsBody?.collisionBitMask = 1
            bullet.physicsBody?.contactTestBitMask = 1
            bullet.name = "bullet"
           
            
            
            
        }
        //Position of the family member
       // let randX = Int(CGFloat((UInt32(self.size.width - 500 ))))
      //  let randY = Int(CGFloat((UInt32(self.size.height - 200))))
        let randX = self.size.height - 800
        let randY = self.size.width - 200
        family.position = CGPoint(x:randX , y:randY)
        print("Where is family? \(randX), \(randY)")
        addChild(family)
        //physics of the family member
        let familyBodyTexture = SKTexture(imageNamed: "family_128")
        family.physicsBody = SKPhysicsBody(texture: familyBodyTexture,
                                           size: familyBodyTexture.size())
        family.physicsBody?.isDynamic = false
        family.physicsBody?.allowsRotation = false
        family.physicsBody?.affectedByGravity = false
        family.physicsBody?.categoryBitMask = 1
        family.physicsBody?.collisionBitMask = 6
        family.physicsBody?.contactTestBitMask = 6
        family.name = "family"
        
     
        
    }
}
