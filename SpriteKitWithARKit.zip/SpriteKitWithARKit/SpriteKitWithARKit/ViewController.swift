//
//  ViewController.swift
//  SpriteKitWithARKit
//
//  Created by Manpreet Kaur Gill on 2019-08-08.
//  Copyright © 2019 Manpreet Kaur Gill. All rights reserved.
//

import UIKit
import SpriteKit
import ARKit

class ViewController: UIViewController, ARSKViewDelegate {
    
    @IBOutlet var sceneView: ARSKView!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(UIScreen.main.bounds.height)
        print(UIScreen.main.bounds.width)
        // Set the view's delegate
        guard ARFaceTrackingConfiguration.isSupported else { fatalError() }
        sceneView.delegate = self
        
        // Show statistics such as fps and node count
        sceneView.showsFPS = true
        sceneView.showsNodeCount = true
        sceneView.showsPhysics = true
        
        // Load the SKScene from 'Scene.sks'
        if let scene = SKScene(fileNamed: "Scene3") {
            scene.scaleMode = .aspectFill

            sceneView.presentScene(scene)
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
       // let configuration = ARWorldTrackingConfiguration()
        let configuration = ARFaceTrackingConfiguration()


        // Run the view's session
        sceneView.session.run(configuration)
        
        let jawOpenValue = ARFaceAnchor.BlendShapeLocation.jawOpen.hashValue
        let jawCloseValue = ARFaceAnchor.BlendShapeLocation.mouthClose
        print("hi", jawOpenValue.hashValue)
        print("hi", jawCloseValue.rawValue)
        print("helllllllllllllllo")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
   
    
    func view(_ view: ARSKView, nodeFor anchor: ARAnchor) -> SKNode? {
        // Create and configure a node for the anchor added to the view's session.
        let labelNode = SKLabelNode(text: "👾")
        labelNode.horizontalAlignmentMode = .center
        labelNode.verticalAlignmentMode = .center
        return labelNode;
    }
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
   
    
    
}
